package com.example.semesterproject

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
